package tap_tallerdecarrosmongodb;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class Coneccion {
    
    ConnectionString connectionString = new ConnectionString("mongodb+srv://Alexis:Alexis1@cluster0.bf1t1.mongodb.net/myFirstDatabase?retryWrites=true&w=majority");
    MongoClientSettings settings = MongoClientSettings.builder()
            .applyConnectionString(connectionString)
            .build();
    MongoClient mongoClient = MongoClients.create(settings);
    MongoDatabase database = mongoClient.getDatabase("Registro");

    public MongoDatabase getDatabase() {
        return database;
    }
}
